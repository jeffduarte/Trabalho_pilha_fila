﻿Programa que demonstra o funcionamento das estruturas Pilha e Fila.
feito de uma forma bem interativa, tive o cuidado de fazer várias funções onde
se testa a entrada do usuário para evitar erros. Fiz também uma função para testar
a eficiência do programa dando o tempo que ele demora para realizar algumas funções,
tentei também deixar o mais compatível com o windows e o linux possível, embora ainda
tenha algum bug quando funcionando no linux ele roda nos dois faltando poucos ajustes
para ficar 100% no linux assim como é no windows. Ele é muito focado no usuário,
por isso ele tem muitos saídas visuais para informar o usuário. Seu máximo de nós suportado
é 6.438.231, por limitação do sistema de 32 Bits, que só possibilita o uso de 2GB
por um único programa. Cada nó das estruturas pode armazenar um char e um int.
É prático seu funcionamento e muito didático, abaixo tem explicado seu funcionamento.



Ele inicia com um menu para escolher que tipo de estrutura deseja trabalhar

1 - Pilha
2 - Fila
3 - Sair

Em 1 - pilha, existe as funções:

1 - Inserir Valor:      Ela Insere um inteiro na pilha e pergunta se deseja inserir também um char no mesmo nó.
2 - Inserir Caracteres: Insere um char e pergunta se deseja entrar com um inteiro no mesmo nó.
3 - Imprimir Último:    Imprime o último valor que foi inserido na pilha.
4 - Deletar:            Deleta o último valor da pilha.
5 - Tamanho da Pilha:   Mostra na tela quantos nós existem na estrutura.
6 - Exibir Pilha:       Monstra todos os valores armazenados na pilha.
7 - Esvaziar Pilha:     Deleta todos os nós da pilha
8 - Restaurar ultima:   Restaura o último valor deletado.
9 - Regravar:           Permite reinserir valores no último nó da pilha.
10 - Encher:            Enche a pilha com valores aleatórios, sendo limitado a 6.438.231 nós, em função dos 32Bits.
11 - Busca:             Procura uma informação char com 1 ou um inteiro com 0.
12 - Menu Principal:    Retorna para o primeiro menu de escolha das estruturas


Em 2 - Fila, existe as funções:

1 - Inserir Valor:      Ela Insere um inteiro na Fila e pergunta se deseja inserir também um char no mesmo nó.
2 - Inserir Caracteres: Insere um char e pergunta se deseja entrar com um inteiro no mesmo nó.
3 - Imprimir Primeiro:  Imprime o Primeiro valor que foi inserido na Fila.
4 - Deletar:            Deleta o primeiro valor da Fila.
5 - Tamanho da Fila:    Mostra na tela quantos nós existem na estrutura.
6 - Exibir Fila:        Monstra todos os valores armazenados na Fila.
7 - Esvaziar Fila:      Deleta todos os nós da Fila
8 - Restaurar ultima:   Restaura o último valor deletado.
9 - Regravar:           Permite reinserir valores no último nó da Fila.
10 - Encher:            Enche a Fila com valores aleatórios, sendo limitado a 6.438.231 nós, em função dos 32Bits.
11 - Busca:             Procura uma informação char com 1 ou um inteiro com 0.
12 - Menu Principal:    Retorna para o primeiro menu de escolha das estruturas


Em 3 - Sair, simplesmente sai do programa.



É um programa interessante que exemplifica muito bem como funcionam os dois tipos de estrutura fila e pilha.


Atividade de Estrutura de dados I, MATA40 UFBA 2014.2
Atividade do professor Danilo Silva dos Santos.

					Implementado completamente por Jeferson Duarte de Oliveira Barbosa Filho.
							2014.